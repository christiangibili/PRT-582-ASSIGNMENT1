
from operator import truediv
import random
from re import L

input_of_the_user = [1,2,3] # The computer will choose this variable to determine if it is 1, 2, or 3.
computer_score = 0 #This variable represents the computer's score count; if it reaches 5 before another variable, the machine has won.
user_score = 0 #This variable represents the user's score; if it reaches 5 before any other value, the user wins.
Tie = 0 #This Variable is the Draw  count
your_name = "" #This variable is the holder of the user's name when the user types it.

print("********************Welcome to Rock Paper Scissors Game****************************\n You will facing a computer 1 vs 1\n whoever got first 5 points wins")
class RockPaperScissors(object):

    def isInt(self, users):
        try:
            int(users)
            return True           #this section is used to determine whether a user's variable can only utilise an integer..
        except ValueError:
            return False

    def the_whole_game(self , users, computer):
        users = int(users)
        
        if users == computer:
            result = "Its a Tie"
        #In this section, the outcome of the user's choice in the game of Rock, Paper, Scissors will be determined.
            
        elif users== 1 and computer == 2:
            result = "You picked: Rock and the Computer picked Paper. You Lose!"
            
        elif users == 1 and computer == 3:
            result = "You picked: Rock and the Computer picked Scissors. You Win!\U0001f600"
            
        elif users == 2 and computer == 1:
            result  = "You picked: Paper and the Computer picked Rock. You Win!\U0001f600"
            
        elif users == 2 and computer == 3:
            result = "You picked: Paper and the Computer picked Scissors. You Lose!"
            
        elif users == 3 and computer == 1:
            result = "You picked: Scissors and the Computer picked Rock. You Lose!"
            
        elif users == 3 and computer == 2:
            result = "You picked: Scissors and the Computer picked Paper. You Win!\U0001f600"
        
        elif users == 4:
            return False
            
        else: 
            result = "Invalid Input" 
        
        return result

your_name  = (input("Enter your Name: "))
restart = ""
users = 0
computer = 0
while(user_score != 5 and computer_score !=5): #If neither the human nor the machine has a score of five in this loop, the loop will continue.
    while True:
        computer = random.choice(input_of_the_user) #The computer will randomly pick any in the variable of input_of_the_user
        score_counter = RockPaperScissors.the_whole_game(RockPaperScissors,users,computer) #calling the def the_whole_game
        users = int(input("Choose [1] for rock, [2] for paper [3] scissors and press any number to quit except for 1,2,3 "))     #This where the user choose his move against computer
        if (users == 1 or users == 2 or users == 3):        #If the user selects any of 1, 2, or 3 in this if statement, it will eventually break.
            break
        
            
        else:
            print("Thanks for playing") 
            #If the user choose wrong number it will eventually exit the game
            exit()
        
           
    
    
    if (score_counter == "Its a Tie"):
        
        Tie += 1
    elif (score_counter == "You picked: Rock and the Computer picked Paper. You Lose!" ):
        computer_score+=1
    elif (score_counter == "You picked: Rock and the Computer picked Scissors. You Win!\U0001f600"):
        user_score +=1
    elif (score_counter == "You picked: Paper and the Computer picked Rock. You Win!\U0001f600"):
        user_score+=1
    elif (score_counter== "You picked: Paper and the Computer picked Scissors. You Lose!"):
        computer_score+=1    
    elif (score_counter== "You picked: Scissors and the Computer picked Rock. You Lose!"):
        computer_score +=1
    elif (score_counter == "You picked: Scissors and the Computer picked Paper. You Win!\U0001f600"):
    #This if-else statement will only add a score or draw total it depends on the condition.
        user_score +=1
    
    print(score_counter)
    print(your_name,"'s score is: ", user_score )#This is to show the score of computer and user
    print("Computer Score: ", computer_score)
    print("Draw: ", Tie)#draw counter
if computer == 5:
    print("The winner is Computer\n with a score of ", computer_score) 

else:
    print("The winner is ",your_name,"with a score of " , user_score)
      
print("Thanks for Playing!  \U0001F606", your_name) #this will print if while statement meets it's condition to end the loop  


  
    



  
    

  

              


         


    








            




        


 

    

        
            
