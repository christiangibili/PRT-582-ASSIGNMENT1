import unittest
from RockPaperScissors import RockPaperScissors

class MyTestCase(unittest.TestCase):
    rockpaperscissors = RockPaperScissors()

    def test_is_Int(self):
        self.assertTrue(self.rockpaperscissors.isInt(1)) #this section is to check if users only use integer.
        self.assertFalse(self.rockpaperscissors.isInt("saasd123"))

    def test_whole_game(self): #This test for the whole game of what's gonna be if the user and computer pick something in the choices
        self.assertEqual(self.rockpaperscissors.the_whole_game(1, 1), "Its a Tie")
        self.assertEqual(self.rockpaperscissors.the_whole_game(1, 2), "You picked: Rock and the Computer picked Paper. You Lose!")
        self.assertEqual(self.rockpaperscissors.the_whole_game(1, 3), "You picked: Rock and the Computer picked Scissors. You Win!\U0001f600")
        self.assertEqual(self.rockpaperscissors.the_whole_game(2, 1), "You picked: Paper and the Computer picked Rock. You Win!\U0001f600")
        self.assertEqual(self.rockpaperscissors.the_whole_game(2, 3), "You picked: Paper and the Computer picked Scissors. You Lose!")
        self.assertEqual(self.rockpaperscissors.the_whole_game(3, 1), "You picked: Scissors and the Computer picked Rock. You Lose!")
        self.assertEqual(self.rockpaperscissors.the_whole_game(3, 2), "You picked: Scissors and the Computer picked Paper. You Win!\U0001f600")
        self.assertNotEqual(self.rockpaperscissors.the_whole_game(2, 1), "Its a Tie")
        self.assertNotEqual(self.rockpaperscissors.the_whole_game(3, 2), "You Lose")
        self.assertNotEqual(self.rockpaperscissors.the_whole_game(3, 2), "1asdjka")

if __name__ == '__main__':
    unittest.main()